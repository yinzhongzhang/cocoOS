var struct_o_s_msg_q__t =
[
    [ "change", "struct_o_s_msg_q__t.html#afc10846deb8f5ac0df1215d8b3077e47", null ],
    [ "q", "struct_o_s_msg_q__t.html#ad82f39d8438ddca5d73b088d7c1df0af", null ],
    [ "taskId", "struct_o_s_msg_q__t.html#a678a01906a4908de435ad546c658cc85", null ]
];