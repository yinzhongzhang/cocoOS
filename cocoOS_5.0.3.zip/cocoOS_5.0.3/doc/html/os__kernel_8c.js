var os__kernel_8c =
[
    [ "os_get_running_tid", "os__kernel_8c.html#a4aa5411405c3a76e6de7f041edce05fa", null ],
    [ "os_init", "os__kernel_8c.html#a6cc2e63d83267ff5059bf0a76b302a09", null ],
    [ "os_running", "os__kernel_8c.html#a943c88e42849b98b803f707d134baf79", null ],
    [ "os_start", "os__kernel_8c.html#a19c7111cf2121a69331d99dabe3e9df0", null ],
    [ "os_sub_nTick", "os__kernel_8c.html#a5b490624895d2f8132bce27f81e7027f", null ],
    [ "os_sub_tick", "os__kernel_8c.html#ac48c31882821ef8c2acef85235ee3d13", null ],
    [ "os_tick", "os__kernel_8c.html#a1d7bc0554f6b515785211dd2c3f2d3d9", null ],
    [ "last_running_task", "os__kernel_8c.html#ac70e02976aa8431691b8fcba2ecb779d", null ],
    [ "running", "os__kernel_8c.html#af77f8244799e85284b8b438289f5f689", null ],
    [ "running_tid", "os__kernel_8c.html#a6857a184b9ad06cadd24899296af802a", null ]
];