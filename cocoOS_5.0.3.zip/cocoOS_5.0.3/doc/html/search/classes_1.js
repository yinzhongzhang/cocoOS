var searchData=
[
  ['osmsgq_5ft',['OSMsgQ_t',['../struct_o_s_msg_q__t.html',1,'']]],
  ['osqueue_5ft',['OSQueue_t',['../struct_o_s_queue__t.html',1,'']]]
];
