var searchData=
[
  ['task_5fcreate',['task_create',['../os__task_8c.html#af531a501491c2acab61a65c8741e1375',1,'os_task.c']]],
  ['task_5fget_5fdata',['task_get_data',['../os__task_8c.html#a61293c64d8794582ff89ca7c27ba7d7d',1,'os_task.c']]],
  ['task_5fkill',['task_kill',['../os__task_8c.html#ac98b20fb840196c24a41c72ae03cfe5f',1,'os_task.c']]],
  ['task_5fstate_5fget',['task_state_get',['../os__task_8c.html#a250fb484aede328b860ec5661fec2ee4',1,'os_task.c']]]
];
