var searchData=
[
  ['waitq',['waitQ',['../structtcb.html#a50e48c5947e1556ea36ac9d2387a9212',1,'tcb']]],
  ['waitsingleevent',['waitSingleEvent',['../structtcb.html#afc6b3432b0eb3a76a5ce12d44e07482b',1,'tcb']]]
];
