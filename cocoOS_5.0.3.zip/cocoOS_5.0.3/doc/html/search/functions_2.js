var searchData=
[
  ['sem_5fbin_5fcreate',['sem_bin_create',['../os__sem_8c.html#aaecd95706696b8ff18d5ef74d139d750',1,'os_sem.c']]],
  ['sem_5fcounting_5fcreate',['sem_counting_create',['../os__sem_8c.html#a9cfb5b3cc72fdaed17009a0cae7fd725',1,'os_sem.c']]]
];
