var searchData=
[
  ['running',['running',['../os__kernel_8c.html#af77f8244799e85284b8b438289f5f689',1,'os_kernel.c']]],
  ['running_5ftid',['running_tid',['../os__kernel_8c.html#a6857a184b9ad06cadd24899296af802a',1,'os_kernel.c']]]
];
