var searchData=
[
  ['last_5frunning_5ftask',['last_running_task',['../os__kernel_8c.html#ac70e02976aa8431691b8fcba2ecb779d',1,'os_kernel.c']]],
  ['list',['list',['../struct_o_s_queue__t.html#acbdee7a47addf7e78ed12916d61dfe13',1,'OSQueue_t']]]
];
