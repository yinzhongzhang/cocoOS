var searchData=
[
  ['event_5fcreate',['event_create',['../os__event_8c.html#a04ba027b0848884aa6a2f5a346444be3',1,'os_event.c']]],
  ['event_5flast_5fsignaled_5fget',['event_last_signaled_get',['../os__event_8c.html#a72a84fa2b2c57833a600d5463c3095c1',1,'os_event.c']]],
  ['event_5fsignaling_5ftaskid_5fget',['event_signaling_taskId_get',['../os__event_8c.html#ae28468ad6bb58df9d34ebd5bd3daa548',1,'os_event.c']]],
  ['event_5ft',['Event_t',['../struct_event__t.html',1,'']]],
  ['eventqueue',['eventQueue',['../structtcb.html#a96e6ab9342c4a3c8ba4e2e9ed5b249be',1,'tcb']]]
];
