var searchData=
[
  ['savedstate',['savedState',['../structtcb.html#abfac7ca3b434b2eca39dbbc98997400e',1,'tcb']]],
  ['semaphore',['semaphore',['../structtcb.html#a3274c5c0859519c77745aee82e85c100',1,'tcb']]],
  ['signaledbytid',['signaledByTid',['../struct_event__t.html#a1040c22e39bbb547df630546c5ce29a5',1,'Event_t']]],
  ['size',['size',['../struct_o_s_queue__t.html#ae5dc6ffcd9b7605c7787791e40cc6bb0',1,'OSQueue_t']]],
  ['state',['state',['../structtcb.html#a84a8b308652d9493d14d5626cf75be92',1,'tcb']]]
];
