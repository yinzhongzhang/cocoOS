var searchData=
[
  ['pad',['pad',['../struct_o_s_queue__t.html#afe23e4c59de249880511510ea325a1ad',1,'OSQueue_t']]],
  ['prio',['prio',['../structtcb.html#acc0b27a6740f03639727be452f1e6b83',1,'tcb']]]
];
