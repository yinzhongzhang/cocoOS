var searchData=
[
  ['change',['change',['../struct_o_s_msg_q__t.html#afc10846deb8f5ac0df1215d8b3077e47',1,'OSMsgQ_t']]],
  ['clockid',['clockId',['../structtcb.html#a419ca43cd619bee2e2fe3799adc8524c',1,'tcb']]]
];
