var searchData=
[
  ['savedstate',['savedState',['../structtcb.html#abfac7ca3b434b2eca39dbbc98997400e',1,'tcb']]],
  ['sem_5fbin_5fcreate',['sem_bin_create',['../os__sem_8c.html#aaecd95706696b8ff18d5ef74d139d750',1,'os_sem.c']]],
  ['sem_5fcounting_5fcreate',['sem_counting_create',['../os__sem_8c.html#a9cfb5b3cc72fdaed17009a0cae7fd725',1,'os_sem.c']]],
  ['semaphore',['semaphore',['../structtcb.html#a3274c5c0859519c77745aee82e85c100',1,'tcb']]],
  ['semvalue_5ft',['SemValue_t',['../struct_sem_value__t.html',1,'']]],
  ['signaledbytid',['signaledByTid',['../struct_event__t.html#a1040c22e39bbb547df630546c5ce29a5',1,'Event_t']]],
  ['size',['size',['../struct_o_s_queue__t.html#ae5dc6ffcd9b7605c7787791e40cc6bb0',1,'OSQueue_t']]],
  ['state',['state',['../structtcb.html#a84a8b308652d9493d14d5626cf75be92',1,'tcb']]]
];
