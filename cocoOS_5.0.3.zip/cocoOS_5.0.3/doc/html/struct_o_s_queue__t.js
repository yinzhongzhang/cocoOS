var struct_o_s_queue__t =
[
    [ "head", "struct_o_s_queue__t.html#a9794c0e61506b826b49b458708ae2489", null ],
    [ "list", "struct_o_s_queue__t.html#acbdee7a47addf7e78ed12916d61dfe13", null ],
    [ "messageSize", "struct_o_s_queue__t.html#aa1a1001750b7ef127a50e908c45a62c6", null ],
    [ "pad", "struct_o_s_queue__t.html#afe23e4c59de249880511510ea325a1ad", null ],
    [ "size", "struct_o_s_queue__t.html#ae5dc6ffcd9b7605c7787791e40cc6bb0", null ],
    [ "tail", "struct_o_s_queue__t.html#a8db7f977b77e4e4d588ef0d3e04ada16", null ]
];