var struct_sem_value__t =
[
    [ "maxValue", "struct_sem_value__t.html#ade4fb08a2a6490e1e820805ace2cbdf8", null ],
    [ "value", "struct_sem_value__t.html#a638e4503e0ae6ce655b7ad2e17e8f0ad", null ]
];