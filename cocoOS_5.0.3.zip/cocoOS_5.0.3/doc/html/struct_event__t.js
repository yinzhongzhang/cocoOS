var struct_event__t =
[
    [ "id", "struct_event__t.html#a1e6927fa1486224044e568f9c370519b", null ],
    [ "signaledByTid", "struct_event__t.html#a1040c22e39bbb547df630546c5ce29a5", null ]
];