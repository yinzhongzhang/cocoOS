var os__event_8c =
[
    [ "Event_t", "struct_event__t.html", "struct_event__t" ],
    [ "event_create", "os__event_8c.html#a04ba027b0848884aa6a2f5a346444be3", null ],
    [ "event_last_signaled_get", "os__event_8c.html#a72a84fa2b2c57833a600d5463c3095c1", null ],
    [ "event_signaling_taskId_get", "os__event_8c.html#ae28468ad6bb58df9d34ebd5bd3daa548", null ],
    [ "os_event_init", "os__event_8c.html#a73d4fa65cef28ee6d4f34e3ba30d3eee", null ],
    [ "os_event_set_signaling_tid", "os__event_8c.html#a80983f2fab1a01a7dd6dd4bf0c44ba8d", null ],
    [ "os_signal_event", "os__event_8c.html#a17d4f782e35414af9e80c3c38d6eb76a", null ],
    [ "os_wait_event", "os__event_8c.html#a4d1de8939b3d29f31da78e2c44b3079d", null ],
    [ "os_wait_multiple", "os__event_8c.html#a64b465c9031c95e48d6ac44c531d224c", null ]
];