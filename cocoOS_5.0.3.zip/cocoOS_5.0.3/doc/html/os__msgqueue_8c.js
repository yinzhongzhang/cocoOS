var os__msgqueue_8c =
[
    [ "OSQueue_t", "struct_o_s_queue__t.html", "struct_o_s_queue__t" ],
    [ "OSMsgQ_t", "struct_o_s_msg_q__t.html", "struct_o_s_msg_q__t" ],
    [ "os_msg_post", "os__msgqueue_8c.html#ab72ffe06ce249c9ca5640e9c74a32ecd", null ],
    [ "os_msg_receive", "os__msgqueue_8c.html#ad355c3842f0bce7a9c3e8b90dc1177c6", null ],
    [ "os_msgQ_create", "os__msgqueue_8c.html#a13d199cfa3312885f497deead1699f2c", null ],
    [ "os_msgQ_event_get", "os__msgqueue_8c.html#aa82e3c1762f9dd8caa6f957544183d52", null ],
    [ "os_msgQ_find", "os__msgqueue_8c.html#a54fb2f01622728dd5c8ae855343a7f77", null ],
    [ "os_msgQ_init", "os__msgqueue_8c.html#a609bc3b446df59cc10f30ae6fffc1bea", null ],
    [ "os_msgQ_tick", "os__msgqueue_8c.html#a6c6dd585336321ca24c169a94c352120", null ]
];