var annotated =
[
    [ "Event_t", "struct_event__t.html", "struct_event__t" ],
    [ "OSMsgQ_t", "struct_o_s_msg_q__t.html", "struct_o_s_msg_q__t" ],
    [ "OSQueue_t", "struct_o_s_queue__t.html", "struct_o_s_queue__t" ],
    [ "SemValue_t", "struct_sem_value__t.html", "struct_sem_value__t" ],
    [ "tcb", "structtcb.html", "structtcb" ]
];