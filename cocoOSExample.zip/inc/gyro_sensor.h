#ifndef GYRO_SENSOR_H_
#define GYRO_SENSOR_H_

#include "sensor.h"

Sensor_t *gyroSensor_get(void);
void gyroSensor_service(void);

#endif /* GYRO_SENSOR_H_ */
